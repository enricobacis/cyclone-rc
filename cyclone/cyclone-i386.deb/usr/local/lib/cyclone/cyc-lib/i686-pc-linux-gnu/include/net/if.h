__noinference__{
#ifndef _NET_IF_H_
#define _NET_IF_H_
#endif
}
