__noinference__{
#ifndef _NETINET_TCP_H_
#define _NETINET_TCP_H_
#ifndef TCP_NODELAY
#define TCP_NODELAY 1
#endif
#endif
}
