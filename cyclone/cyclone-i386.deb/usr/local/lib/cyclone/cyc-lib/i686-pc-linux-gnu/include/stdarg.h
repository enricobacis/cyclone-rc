__noinference__{
#ifndef _STDARG_H_
#define _STDARG_H_
#ifndef ___gnuc_va_list_def_
#define ___gnuc_va_list_def_
typedef int __gnuc_va_list;
#endif
#ifndef _va_list_def_
#define _va_list_def_
typedef __gnuc_va_list va_list;
#endif


#endif
}
