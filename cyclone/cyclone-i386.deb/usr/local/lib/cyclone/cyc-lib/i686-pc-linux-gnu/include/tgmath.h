__noinference__{
#ifndef _TGMATH_H_
#define _TGMATH_H_
#endif
}
