__noinference__{
#ifndef _SYS_SHM_H_
#define _SYS_SHM_H_
#endif
}
