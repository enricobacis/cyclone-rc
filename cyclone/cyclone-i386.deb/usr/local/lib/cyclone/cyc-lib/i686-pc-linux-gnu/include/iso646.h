__noinference__{
#ifndef _ISO646_H_
#define _ISO646_H_
#ifndef not_eq
#define not_eq !=
#endif
#ifndef and_eq
#define and_eq &=
#endif
#ifndef bitor
#define bitor |
#endif
#ifndef not
#define not !
#endif
#ifndef xor_eq
#define xor_eq ^=
#endif
#ifndef compl
#define compl ~
#endif
#ifndef or_eq
#define or_eq |=
#endif
#ifndef and
#define and &&
#endif
#ifndef bitand
#define bitand &
#endif
#ifndef xor
#define xor ^
#endif
#ifndef or
#define or ||
#endif
#endif
}
