__noinference__{
#ifndef _INTTYPES_H_
#define _INTTYPES_H_
#endif
}
