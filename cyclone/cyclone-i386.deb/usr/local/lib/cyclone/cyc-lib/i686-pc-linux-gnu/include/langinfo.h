__noinference__{
#ifndef _LANGINFO_H_
#define _LANGINFO_H_
#endif
}
