__noinference__{
#ifndef _UCONTEXT_H_
#define _UCONTEXT_H_
#endif
}
