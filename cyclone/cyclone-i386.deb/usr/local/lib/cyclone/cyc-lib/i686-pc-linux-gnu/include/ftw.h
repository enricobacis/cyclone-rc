__noinference__{
#ifndef _FTW_H_
#define _FTW_H_
#endif
}
