__noinference__{
#ifndef _WCTYPE_H_
#define _WCTYPE_H_
#endif
}
