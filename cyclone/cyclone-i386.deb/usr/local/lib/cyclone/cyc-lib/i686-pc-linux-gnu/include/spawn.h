__noinference__{
#ifndef _SPAWN_H_
#define _SPAWN_H_
#endif
}
