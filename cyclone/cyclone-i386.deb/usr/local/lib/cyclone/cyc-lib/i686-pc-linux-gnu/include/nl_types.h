__noinference__{
#ifndef _NL_TYPES_H_
#define _NL_TYPES_H_
#endif
}
