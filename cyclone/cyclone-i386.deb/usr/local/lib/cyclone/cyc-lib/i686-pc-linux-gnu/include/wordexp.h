__noinference__{
#ifndef _WORDEXP_H_
#define _WORDEXP_H_
#endif
}
