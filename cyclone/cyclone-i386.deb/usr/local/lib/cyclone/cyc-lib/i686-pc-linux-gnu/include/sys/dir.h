__noinference__{
#ifndef _SYS_DIR_H_
#define _SYS_DIR_H_

  #include <dirent.h>
#endif
}
