__noinference__{
#ifndef _STDBOOL_H_
#define _STDBOOL_H_
#endif
}
