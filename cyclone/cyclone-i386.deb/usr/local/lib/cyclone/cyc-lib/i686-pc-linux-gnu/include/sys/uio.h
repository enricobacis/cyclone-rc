__noinference__{
#ifndef _SYS_UIO_H_
#define _SYS_UIO_H_
#endif
}
