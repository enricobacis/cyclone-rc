__noinference__{
#ifndef _MONETARY_H_
#define _MONETARY_H_
#endif
}
