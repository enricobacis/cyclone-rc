__noinference__{
#ifndef _SYS_FILE_H_
#define _SYS_FILE_H_
#ifndef F_OK
#define F_OK 0
#endif
#ifndef W_OK
#define W_OK 2
#endif
#ifndef L_INCR
#define L_INCR 1
#endif
#ifndef L_XTND
#define L_XTND 2
#endif
#ifndef R_OK
#define R_OK 4
#endif
#ifndef L_SET
#define L_SET 0
#endif
#ifndef X_OK
#define X_OK 1
#endif

  #include <fcntl.h>
#endif
}
