__noinference__{
#ifndef _SYS_STATVFS_H_
#define _SYS_STATVFS_H_
#endif
}
