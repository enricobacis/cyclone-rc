__noinference__{
#ifndef _SCHED_H_
#define _SCHED_H_
#endif
}
