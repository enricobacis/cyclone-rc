__noinference__{
#ifndef _SEARCH_H_
#define _SEARCH_H_
#endif
}
