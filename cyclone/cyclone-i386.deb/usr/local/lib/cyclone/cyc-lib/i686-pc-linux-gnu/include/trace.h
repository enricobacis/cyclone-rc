#error -- trace.h is not supported on this platform
