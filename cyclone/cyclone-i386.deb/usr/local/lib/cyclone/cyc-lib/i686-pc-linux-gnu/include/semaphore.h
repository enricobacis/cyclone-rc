__noinference__{
#ifndef _SEMAPHORE_H_
#define _SEMAPHORE_H_
#endif
}
