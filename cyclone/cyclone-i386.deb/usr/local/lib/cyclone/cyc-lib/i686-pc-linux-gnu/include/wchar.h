__noinference__{
#ifndef _WCHAR_H_
#define _WCHAR_H_
#endif
}
