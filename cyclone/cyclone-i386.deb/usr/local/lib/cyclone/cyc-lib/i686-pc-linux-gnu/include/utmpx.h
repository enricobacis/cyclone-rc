__noinference__{
#ifndef _UTMPX_H_
#define _UTMPX_H_
#endif
}
