#error -- ndbm.h is not supported on this platform
