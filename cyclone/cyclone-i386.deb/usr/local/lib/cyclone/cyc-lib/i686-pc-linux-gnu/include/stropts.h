__noinference__{
#ifndef _STROPTS_H_
#define _STROPTS_H_

  // FIX: stropts.h is not yet supported.
  // The problem is that the strbuf structure has a char * field. 
#endif
}
