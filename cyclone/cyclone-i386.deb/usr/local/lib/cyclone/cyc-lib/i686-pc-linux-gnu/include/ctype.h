__noinference__{
#ifndef _CTYPE_H_
#define _CTYPE_H_

  extern "C" int isalnum(int);

  extern "C" int isalpha(int);

  extern "C" int isascii(int);

  extern "C" int iscntrl(int);

  extern "C" int isdigit(int);

  extern "C" int isgraph(int);

  extern "C" int islower(int);

  extern "C" int isprint(int);

  extern "C" int ispunct(int);

  extern "C" int isspace(int);

  extern "C" int isupper(int);

  extern "C" int isxdigit(int);

  extern "C" int toascii(int);

  extern "C" int tolower(int);

  extern "C" int toupper(int);

  extern "C" int _tolower(int);

  extern "C" int _toupper(int);
#endif
}
