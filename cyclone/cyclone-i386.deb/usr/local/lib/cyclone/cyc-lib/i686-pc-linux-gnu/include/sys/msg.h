__noinference__{
#ifndef _SYS_MSG_H_
#define _SYS_MSG_H_

  // We don't support this yet
#endif
}
