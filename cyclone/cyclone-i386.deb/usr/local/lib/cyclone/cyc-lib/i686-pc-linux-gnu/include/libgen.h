__noinference__{
#ifndef _LIBGEN_H_
#define _LIBGEN_H_

  // Probably best to do entirely in Cyclone
#endif
}
