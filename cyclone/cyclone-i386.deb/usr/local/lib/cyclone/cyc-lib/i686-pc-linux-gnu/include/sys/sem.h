__noinference__{
#ifndef _SYS_SEM_H_
#define _SYS_SEM_H_
#endif
}
