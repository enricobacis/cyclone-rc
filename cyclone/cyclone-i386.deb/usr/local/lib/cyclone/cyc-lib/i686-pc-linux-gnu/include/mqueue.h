__noinference__{
#ifndef _MQUEUE_H_
#define _MQUEUE_H_
#endif
}
