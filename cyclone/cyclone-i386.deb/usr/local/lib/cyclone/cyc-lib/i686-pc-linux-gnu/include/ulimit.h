__noinference__{
#ifndef _ULIMIT_H_
#define _ULIMIT_H_
#endif
}
