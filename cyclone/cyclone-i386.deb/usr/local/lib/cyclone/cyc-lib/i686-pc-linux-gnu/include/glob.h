__noinference__{
#ifndef _GLOB_H_
#define _GLOB_H_
#endif
}
