__noinference__{
#ifndef _TERMIOS_H_
#define _TERMIOS_H_
#endif
}
